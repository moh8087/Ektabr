<?php
session_start();
session_destroy();
header( 'Location: http://localhost/new_quiz/index.php' ) ;
?>

<!---
Site	:	WWW.FEWPRESS.COM
Author	:	Md. Rokonuzzaman Rokon
--->