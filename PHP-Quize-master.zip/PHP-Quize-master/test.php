<?php
    echo htmlspecialchars('// commented code to end of line');
    
    echo "<br>";
     echo htmlspecialchars('/* commented code here */');
     echo "<br>";
     
      echo htmlspecialchars('#');
      
      echo "<br>";
       echo htmlspecialchars('</php>');
      
      echo "<br>";
       
       
       
?>
