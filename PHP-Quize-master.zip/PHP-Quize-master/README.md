PHP-Quize
=========

PHP Quize
----------------
Responsive Quiz Application Using PHP, MySQL, jQuery, Ajax and Twitter Bootstrap