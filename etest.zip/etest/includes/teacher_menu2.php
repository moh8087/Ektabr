<?php
	
	echo'<!-- Nav -->
							<nav id="nav">
								<ul>
									<li class="current"><a href="teacher.php">الرئيسية</a></li>
									<li>
										<a href="#">الاختبارات</a>
										<ul>
											<li><a href="create_test.php">إنشاء اختبار جديد</a></li>
											<li><a href="mytest.php">اختباراتي</a></li>
											<li><a href="doing_test.php">معاينة اختبار</a></li>
											<li>
												<a href="mytest2.php">إعدادات الاختبار</a>
												<ul>
													<li><a href="#">تعديل اختبار</a></li>
													<li><a href="#">إضافة أسئلة</a></li>
													<li><a href="#">عرض الأسئلة</a></li>
													<li><a href="#">حذف أسئلة</a></li>
												</ul>
											</li>
											
										</ul>
									</li>
									<li><a href="="profile.php">الملف الشخصي</a></li>
									<li><a href="right-sidebar.html">ما هو اختبر</a></li>
									<li><a href="logout.php">تسجيل الخروج</a></li>
								</ul>
							</nav>';
							
							
							
	
	?>
	
	
	
	
