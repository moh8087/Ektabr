<?php
echo'<table class="table">';

    echo '<tr><td><a href="student.php"><img src="images/home.png" title="لوحة تحكم الطالب" /></a> </td> ';
	echo '<td><a href="doing_test.php"><img src="images/exam.png" title="دخول الاختبار" /></a></td>';
  echo '<td><a href="myexams.php" ><img src="images/mylist.png" alt="" /></a></td>';
	echo '<td><a href="change_password2.php" ><img src="images/key.png" title="" /></a></td>';
	echo '<td><a href="profile2.php"><img src="images/profile.png" title="" /></a></td>
	      <td><a href="logout.php"><img src="images/logout.png" title="" /></a></td></tr>';

	echo '<tr ><td><a href="student.php">لوحة التحكم</a> </td> ';
	echo '<td><a href="doing_test.php">دخول الاختبار</a></td>';
  echo '<td><a href="myexams.php">اختباراتي</a></td>';
	echo '<td><a href="change_password2.php">تغيير كلمة المرور</a></td>';
	echo '<td><a href="profile2.php">الملف الشخصي</a></td>
	      <td><a href="logout.php">تسجيل الخروج</a></td></tr>';

	echo '</table>';

	?>
